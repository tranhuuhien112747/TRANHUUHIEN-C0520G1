create
    definer = root@localhost procedure sumNumber(IN a int, IN b int, OUT sum int)
begin
    set sum = sum + a +b;
    set a = sum;
    select sum;
end;

